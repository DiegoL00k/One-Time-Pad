import random

def encrypt(message, key):
    if len(message) != len(key):
        raise ValueError("Message and key must be of equal length")
    
    encrypted_text = ""
    for i in range(len(message)):
        encrypted_text += chr(ord(message[i]) ^ ord(key[i]))

    return encrypted_text

def decrypt(ciphertext, key):
    if len(ciphertext) != len(key):
        raise ValueError("Ciphertext and key must be of equal length")
    
    decrypted_text = ""
    for i in range(len(ciphertext)):
        decrypted_text += chr(ord(ciphertext[i]) ^ ord(key[i]))
    
    return decrypted_text

plaintext = input("Enter the plaintext message: ")

key = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=len(plaintext)))

ciphertext = encrypt(plaintext, key)
print("Encrypted ciphertext:", ciphertext)

decrypted_text = decrypt(ciphertext, key)
print("Decrypted plaintext message:", decrypted_text)